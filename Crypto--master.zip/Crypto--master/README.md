# Crypto-
Contributors- Caleb J Harwood

Concept-
Basic Blockchain that was developed into a crytocurrency using a python on a Spyder server. 
This has yet to still be written with a smart contract. 

To run this file one must first download all the files. 

Then you must download Postman. Ideally, the lastest version and run the file. First you must run the file on the Sypder server
then run it on Postman.
